import { useState } from 'react';
import { Check } from 'lucide-react';
import { PLANS } from '../../data/content';
import { cn } from '../../lib/cn';
import Button from '../ui/Button';
import Container from '../ui/Container';
import Reveal from '../ui/Reveal';
import SectionHeading from '../ui/SectionHeading';

const YEARLY_DISCOUNT = 0.2;

function BillingToggle({ yearly, onChange }) {
  const option = (isYearly, label) => (
    <button
      type="button"
      role="radio"
      aria-checked={yearly === isYearly}
      onClick={() => onChange(isYearly)}
      className={cn(
        'rounded-full px-4 py-2 text-sm font-medium transition-colors duration-200',
        yearly === isYearly ? 'bg-ink text-slip' : 'text-ink/70 hover:text-ink'
      )}
    >
      {label}
    </button>
  );

  return (
    <div role="radiogroup" aria-label="Billing period" className="inline-flex items-center rounded-full border border-ink/15 bg-white p-1">
      {option(false, 'Monthly')}
      {option(true, 'Yearly, save 20%')}
    </div>
  );
}

function PlanCard({ plan, yearly, delay }) {
  const price = yearly ? Math.round(plan.price * (1 - YEARLY_DISCOUNT)) : plan.price;

  return (
    <Reveal
      as="article"
      delay={delay}
      className={cn(
        'relative flex flex-col rounded-2xl p-7 transition duration-300 hover:-translate-y-1',
        plan.popular ? 'bg-ink text-slip shadow-xl shadow-ink/20 lg:-my-4 lg:py-11' : 'border border-ink/10 bg-white'
      )}
    >
      {plan.popular && (
        <span className="absolute -top-3 left-7 rounded-full bg-ochre px-3 py-1 text-xs font-bold text-ink">
          Most popular
        </span>
      )}
      <h3 className="text-xl font-semibold">{plan.name}</h3>
      <p className={cn('mt-1 text-[15px]', plan.popular ? 'text-slip/70' : 'text-ink/65')}>{plan.description}</p>

      <p className="mt-6 flex items-baseline gap-1">
        <span className="font-display text-5xl font-semibold tracking-tight">${price}</span>
        <span className={plan.popular ? 'text-slip/70' : 'text-ink/60'}>per month</span>
      </p>
      <p className={cn('mt-1 h-5 text-sm', plan.popular ? 'text-slip/60' : 'text-ink/50')}>
        {yearly ? 'Billed yearly' : 'Billed monthly'}
      </p>

      <ul className="mt-6 flex-1 space-y-3">
        {plan.features.map((f) => (
          <li key={f} className="flex items-start gap-3 text-[15px]">
            <Check size={18} aria-hidden="true" className={cn('mt-0.5 shrink-0', plan.popular ? 'text-ochre' : 'text-cobalt')} />
            {f}
          </li>
        ))}
      </ul>

      <Button
        href="#contact"
        size="lg"
        variant={plan.popular ? 'light' : 'secondary'}
        className="mt-8 w-full"
      >
        {plan.cta}
      </Button>
    </Reveal>
  );
}

export default function Pricing() {
  const [yearly, setYearly] = useState(true);

  return (
    <section id="pricing" aria-labelledby="pricing-title" className="scroll-mt-20 py-20 sm:py-28">
      <Container>
        <Reveal className="flex flex-col items-center">
          <SectionHeading
            id="pricing-title"
            align="center"
            title="Simple pricing that grows with your studio"
            description="Every plan starts with a 30-day free trial. Cancel any time."
          />
          <div className="mt-8">
            <BillingToggle yearly={yearly} onChange={setYearly} />
          </div>
        </Reveal>

        <div className="mx-auto mt-14 grid max-w-md gap-8 lg:max-w-none lg:grid-cols-3 lg:items-stretch lg:gap-6">
          {PLANS.map((plan, i) => (
            <PlanCard key={plan.name} plan={plan} yearly={yearly} delay={i * 100} />
          ))}
        </div>
      </Container>
    </section>
  );
}
