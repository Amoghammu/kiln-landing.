import { ArrowRight, Play } from 'lucide-react';
import Button from '../ui/Button';
import Container from '../ui/Container';
import KilnLoad from '../ui/KilnLoad';

const rise = (ms) => ({ animationDelay: `${ms}ms` });

export default function Hero() {
  return (
    <section aria-labelledby="hero-title" className="pb-20 pt-32 sm:pb-28 sm:pt-36 lg:pt-40">
      <Container className="grid items-center gap-12 lg:grid-cols-[1.05fr_1fr] lg:gap-16">
        <div>
          <h1
            id="hero-title"
            style={rise(0)}
            className="animate-rise text-4xl font-semibold leading-[1.05] tracking-tight sm:text-5xl lg:text-6xl"
          >
            Run your pottery studio without the clipboard
          </h1>
          <p style={rise(120)} className="animate-rise mt-6 max-w-xl text-lg leading-relaxed text-ink/70">
            Kiln keeps class bookings, memberships and every firing in one place, so nothing gets lost between the
            wheel and the kiln.
          </p>
          <div style={rise(240)} className="animate-rise mt-8 flex flex-col gap-3 sm:flex-row">
            <Button href="#pricing" size="lg">
              Start free for 30 days
              <ArrowRight size={18} aria-hidden="true" />
            </Button>
            <Button href="#how-it-works" size="lg" variant="secondary">
              <Play size={16} aria-hidden="true" />
              See how it works
            </Button>
          </div>
          <p style={rise(360)} className="animate-rise mt-6 text-sm text-ink/60">
            No card needed. Trusted by 480 studios in 31 countries.
          </p>
        </div>

        <div style={rise(300)} className="animate-rise">
          <KilnLoad />
        </div>
      </Container>
    </section>
  );
}
