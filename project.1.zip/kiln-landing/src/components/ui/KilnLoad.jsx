import { useMemo, useState } from 'react';
import { RotateCcw } from 'lucide-react';
import { cn } from '../../lib/cn';

const STAGES = ['Greenware', 'Bisque', 'Glazed', 'Fired'];

const STAGE_CHIP = [
  'bg-ink/10 text-ink',
  'bg-white text-ink',
  'bg-ochre/40 text-ink',
  'bg-cobalt text-white',
];

const SHAPES = {
  bowl: { paths: ['M10 34 H70 C70 56 56 68 40 68 C24 68 10 56 10 34 Z'] },
  vase: {
    paths: ['M32 10 H48 V20 C48 28 62 32 62 50 C62 64 52 70 40 70 C28 70 18 64 18 50 C18 32 32 28 32 20 Z'],
  },
  mug: { paths: ['M18 22 H52 V58 C52 64 48 68 42 68 H28 C22 68 18 64 18 58 Z'], handle: 'M52 30 H58 C66 30 66 52 58 52 H52' },
  plate: { paths: ['M6 52 C6 46 20 42 40 42 C60 42 74 46 74 52 C74 58 60 62 40 62 C20 62 6 58 6 52 Z'] },
  jar: { paths: ['M24 24 H56 V32 C64 36 66 48 62 58 C60 66 52 70 40 70 C28 70 20 66 18 58 C14 48 16 36 24 32 Z', 'M28 14 H52 V24 H28 Z'] },
  cup: { paths: ['M26 16 H54 L50 68 H30 Z'] },
};

const INITIAL = [
  { id: 1, shape: 'bowl', maker: 'Anita', glaze: '#2F4FA8', stage: 0 },
  { id: 2, shape: 'vase', maker: 'Marcus', glaze: '#E3A72F', stage: 1 },
  { id: 3, shape: 'mug', maker: 'Priya', glaze: '#4F7C69', stage: 2 },
  { id: 4, shape: 'plate', maker: 'Joon', glaze: '#2F4FA8', stage: 3 },
  { id: 5, shape: 'jar', maker: 'Lena', glaze: '#E3A72F', stage: 0 },
  { id: 6, shape: 'mug', maker: 'Tomas', glaze: '#2F4FA8', stage: 1 },
  { id: 7, shape: 'bowl', maker: 'Ife', glaze: '#A8442B', stage: 2 },
  { id: 8, shape: 'vase', maker: 'Sam', glaze: '#2F4FA8', stage: 2 },
  { id: 9, shape: 'cup', maker: 'Rae', glaze: '#E3A72F', stage: 3 },
];

function Piece({ shape, glaze, stage }) {
  const { paths, handle } = SHAPES[shape];
  const base = stage === 0 ? '#B3AC9E' : '#E6DAC8';
  const glazeOpacity = stage === 2 ? 0.6 : stage === 3 ? 1 : 0;
  const fade = { transition: 'fill 500ms ease, stroke 500ms ease, opacity 500ms ease' };

  return (
    <svg viewBox="0 0 80 80" className="h-16 w-16 sm:h-20 sm:w-20" aria-hidden="true">
      {handle && (
        <>
          <path d={handle} fill="none" strokeWidth="6" strokeLinecap="round" style={{ ...fade, stroke: base }} />
          <path d={handle} fill="none" strokeWidth="6" strokeLinecap="round" style={{ ...fade, stroke: glaze, opacity: glazeOpacity }} />
        </>
      )}
      {paths.map((d) => (
        <g key={d}>
          <path d={d} style={{ ...fade, fill: base }} />
          <path d={d} style={{ ...fade, fill: glaze, opacity: glazeOpacity }} />
        </g>
      ))}
      <path
        d="M20 40 C20 50 24 58 30 62"
        fill="none"
        stroke="#fff"
        strokeWidth="3"
        strokeLinecap="round"
        style={{ ...fade, opacity: stage === 3 ? 0.4 : 0 }}
      />
    </svg>
  );
}

/** Interactive kiln shelf: click a piece to move it to the next firing stage. */
export default function KilnLoad() {
  const [pieces, setPieces] = useState(INITIAL);

  const fired = useMemo(() => pieces.filter((p) => p.stage === 3).length, [pieces]);
  const advance = (id) =>
    setPieces((list) => list.map((p) => (p.id === id ? { ...p, stage: (p.stage + 1) % STAGES.length } : p)));
  const reset = () => setPieces(INITIAL);

  const shelves = [pieces.slice(0, 3), pieces.slice(3, 6), pieces.slice(6, 9)];

  return (
    <div className="rounded-3xl bg-celadon p-4 sm:p-6">
      <div className="flex items-center justify-between gap-3 px-1 pb-4">
        <div>
          <p className="font-display text-lg font-semibold leading-tight">Friday cone 6 firing</p>
          <p className="text-sm text-ink/70" aria-live="polite">
            {fired} of {pieces.length} pieces fired
          </p>
        </div>
        <button
          type="button"
          onClick={reset}
          className="inline-flex items-center gap-1.5 rounded-full bg-white/70 px-3 py-1.5 text-sm font-medium transition hover:bg-white"
        >
          <RotateCcw size={14} aria-hidden="true" />
          Reset
        </button>
      </div>

      <div className="rounded-2xl bg-slip px-3 pb-3 pt-4 sm:px-5">
        {shelves.map((shelf, i) => (
          <div key={i} className="mb-2 last:mb-0">
            <div className="grid grid-cols-3 gap-2">
              {shelf.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => advance(p.id)}
                  aria-label={`${p.maker}'s ${p.shape}, ${STAGES[p.stage]}. Move to next stage.`}
                  className="group flex flex-col items-center gap-1 rounded-xl px-1 pt-1 transition duration-200 hover:-translate-y-1"
                >
                  <Piece shape={p.shape} glaze={p.glaze} stage={p.stage} />
                  <span className="text-xs font-medium text-ink/70">{p.maker}</span>
                  <span
                    className={cn(
                      'rounded-full px-2 py-0.5 text-[11px] font-medium transition-colors duration-500',
                      STAGE_CHIP[p.stage]
                    )}
                  >
                    {STAGES[p.stage]}
                  </span>
                </button>
              ))}
            </div>
            <div className="mt-2 h-2 rounded-full bg-ink" />
          </div>
        ))}
      </div>

      <p className="px-1 pt-3 text-sm text-ink/70">Tap any piece to move it to its next stage.</p>
    </div>
  );
}
