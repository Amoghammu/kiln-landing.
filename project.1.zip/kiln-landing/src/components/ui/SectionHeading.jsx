import { cn } from '../../lib/cn';

export default function SectionHeading({ id, title, description, align = 'left', className }) {
  return (
    <div className={cn('max-w-2xl', align === 'center' && 'mx-auto text-center', className)}>
      <h2 id={id} className="text-3xl font-semibold tracking-tight sm:text-4xl lg:text-5xl">
        {title}
      </h2>
      {description && <p className="mt-4 text-lg leading-relaxed text-ink/70">{description}</p>}
    </div>
  );
}
